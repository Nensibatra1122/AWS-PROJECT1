#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/adjust_results4_isadog_hints.py
#                                                                             
# PROGRAMMER: Nensi Batra
# DATE CREATED: 15 Aug 2024                                 
# REVISED DATE: 
# PURPOSE: This script adjusts the results dictionary to determine if the 
#          classifier correctly identified images as 'a dog' or 'not a dog.'
#          It verifies if the model accurately classifies dog images even
#          when the specific breed is incorrectly identified (not a match).
#          The script compares labels from the pet images and classifier 
#          with the dog names listed in a provided file (dognames.txt).
#          The function updates the dictionary by adding two elements:
#          whether the pet image label is a dog and whether the classifier
#          label is a dog, using indices 3 and 4 respectively.
#
##
# FUNCTION adjust_results4_isadog: 
#       Modifies the results_dic dictionary by adding two new indices
#       that indicate if the pet image label and the classifier label
#       correspond to a dog or not.
#       No return statement is needed as results_dic is mutable.
# 
def adjust_results4_isadog(results_dic, dogfile):
    """
    Updates the results dictionary to reflect whether each label is a dog.
    
    Parameters:
      results_dic - Dictionary with 'key' as image filename and 'value' as a 
                    List. The list contains:
                  index 0 = pet image label (string)
                  index 1 = classifier label (string)
                  index 2 = 1/0 (int)  where 1 = match between pet image
                    and classifier labels, and 0 = no match.
                ------ New indices added by this function -----
                 index 3 = 1/0 (int)  where 1 = pet image label is a dog,
                            0 = pet image label is not a dog.
                 index 4 = 1/0 (int)  where 1 = classifier label is a dog,
                            0 = classifier label is not a dog.
     dogfile - Text file containing names of all recognized dog breeds.
               Each line contains one dog name in lowercase with words
               separated by spaces. Some dog breeds have multiple names
               listed (e.g., maltese dog, maltese terrier, maltese).
               
    Returns:
           None - results_dic is updated in-place.
    """           
    # Create a set for fast lookup of dog names
    dognames_set = set()

    # Read and process the dogfile
    with open(dogfile, "r") as infile:
        for line in infile:
            # Strip newline and add to the set
            dognames_set.add(line.strip())

    # Iterate through results_dic to update dog classification info
    for key, value in results_dic.items():
        # Determine if the pet label is a dog
        is_pet_dog = 1 if value[0] in dognames_set else 0
        
        # Determine if the classifier label is a dog
        is_classifier_dog = 1 if value[1] in dognames_set else 0
        
        # Append these results to the existing list
        value.extend([is_pet_dog, is_classifier_dog])
