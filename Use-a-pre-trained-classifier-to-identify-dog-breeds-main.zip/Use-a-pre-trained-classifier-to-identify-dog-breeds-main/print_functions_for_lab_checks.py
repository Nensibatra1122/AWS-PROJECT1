#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND/intropylab-classifying-images/print_functions_for_lab_checks.py
#                                                                             
# PROGRAMMER: Jennifer S.                                                    
# DATE CREATED: 05/14/2018                                  
# REVISED DATE:             <=(Date Revised - if any)                         
# PURPOSE:  This set of functions is designed to assist in verifying your code 
#           after implementing each function. The initial sections of the lab 
#           contain a segment titled 'Checking your code'. When instructed in 
#           this section, use these functions to facilitate code verification. 
#           Refer to the docstrings of each function for usage details.
#
##

# Functions to aid in "Checking your code", specifically
# invoking these functions with appropriate input arguments in the
# main() function will print necessary information for verification
#
def check_command_line_arguments(in_arg):
    """
    For Lab: Classifying Images - 7. Command Line Arguments
    Displays each command line argument passed as in_arg, 
    assuming you have set all three command line arguments as described in 
    '7. Command Line Arguments'
    Parameters:
     in_arg - data structure holding the command line arguments object
    Returns:
     Nothing - just outputs to console  
    """
    if in_arg is None:
        print("* Cannot Check Command Line Arguments because 'get_input_args' is not defined.")
    else:
        # Print command line arguments
        print("Command Line Arguments:\n     dir =", in_arg.dir, 
              "\n    arch =", in_arg.arch, "\n dogfile =", in_arg.dogfile)

def check_creating_pet_image_labels(results_dic):
    """    
    For Lab: Classifying Images - 9/10. Creating Pet Image Labels
    Displays the first 10 key-value pairs and confirms there are 40 key-value 
    pairs in the results_dic dictionary. Assumes results_dic was defined as outlined in 
    '9/10. Creating Pet Image Labels'
    Parameters:
      results_dic - Dictionary with key as image filename and value as a List 
             (index)idx 0 = pet image label (string)
    Returns:
     Nothing - just outputs to console  
    """
    if results_dic is None:
        print("* Cannot Check Results Dictionary because 'get_pet_labels' is not defined.")
    else:
        # Print 10 key-value pairs (or fewer if less than 10 images)
        stop_point = min(len(results_dic), 10)
        print("\nPet Image Label Dictionary has", len(results_dic),
              "key-value pairs.\nBelow are", stop_point, "of them:")
    
        # Counter for printed labels
        n = 0
    
        # Loop through the dictionary
        for key in results_dic:
 
            # Print only the first 10 labels
            if n < stop_point:
                print("{:2d} key: {:>30}  label: {:>26}".format(n+1, key,
                      results_dic[key][0]))

                # Increment counter
                n += 1
            
            # Break the loop after the first 10 labels
            else:
                break

def check_classifying_images(results_dic):
    """    
    For Lab: Classifying Images - 11/12. Classifying Images
    Displays Pet Image Label and Classifier Label for all matches, followed by all 
    non-matches. Also prints the total number of images, number of matches, and 
    non-matches to verify all images are processed. Assumes results_dic was defined as 
    outlined in '11/12. Classifying Images'
    Parameters:
      results_dic - Dictionary with key as image filename and value as a List 
             (index)idx 0 = pet image label (string)
                    idx 1 = classifier label (string)
                    idx 2 = 1/0 (int)   where 1 = match between pet image and 
                    classifier labels and 0 = no match between labels
    Returns:
     Nothing - just outputs to console  
    """
    if results_dic is None:
        print("* Cannot Check Results Dictionary because 'classify_images' is not defined.")
    elif len(results_dic[next(iter(results_dic))]) < 2:
        print("* Cannot Check Results Dictionary because 'classify_images' is not defined.")
    else:
        # Initialize counters for matches and non-matches
        n_match = 0
        n_notmatch = 0
    
        # Print all matches first
        print("\n     MATCH:")
        for key in results_dic:

            # Print only if a match (Index 2 == 1)
            if results_dic[key][2] == 1:

                # Increment match counter
                n_match += 1
                print("\n{:>30}: \nReal: {:>26}   Classifier: {:>30}".format(key, 
                      results_dic[key][0], results_dic[key][1]))

        # Print all non-matches next
        print("\n NOT A MATCH:")
        for key in results_dic:
        
            # Print only if not a match (Index 2 == 0)
            if results_dic[key][2] == 0:
 
                # Increment non-match counter
                n_notmatch += 1
                print("\n{:>30}: \nReal: {:>26}   Classifier: {:>30}".format(key,
                      results_dic[key][0], results_dic[key][1]))

        # Print total number of images, matches, and non-matches
        print("\n# Total Images",n_match + n_notmatch, "# Matches:",n_match ,
              "# NOT Matches:",n_notmatch)

def check_classifying_labels_as_dogs(results_dic):
    """    
    For Lab: Classifying Images - 13. Classifying Labels as Dogs
    Displays Pet Image Label, Classifier Label, whether Pet Label is a dog (1=Yes,
    0=No), and whether Classifier Label is a dog (1=Yes, 0=No) for all matches 
    followed by all non-matches. Also prints the total number of images, matches, and 
    non-matches. Assumes results_dic was defined as outlined in '13. Classifying Labels as Dogs'
    Parameters:
      results_dic - Dictionary with key as image filename and value as a List 
             (index)idx 0 = pet image label (string)
                    idx 1 = classifier label (string)
                    idx 2 = 1/0 (int)   where 1 = match between pet image and 
                    classifier labels and 0 = no match between labels
                    idx 3 = 1/0 (int)  where 1 = pet image 'is-a' dog and 
                            0 = pet Image 'is-NOT-a' dog. 
                    idx 4 = 1/0 (int)  where 1 = Classifier classifies image 
                            'as-a' dog and 0 = Classifier classifies image  
                            'as-NOT-a' dog.
    Returns:
     Nothing - just outputs to console  
    """
    if results_dic is None:
        print("* Cannot Check Results Dictionary because 'adjust_results4_isadog' is not defined.")
    elif len(results_dic[next(iter(results_dic))]) < 4:
        print("* Cannot Check Results Dictionary because 'adjust_results4_isadog' is not defined.")
    else:
        # Initialize counters for matches and non-matches
        n_match = 0
        n_notmatch = 0
    
        # Print all matches first
        print("\n     MATCH:")
        for key in results_dic:

            # Print only if a match (Index 2 == 1)
            if results_dic[key][2] == 1:

                # Increment match counter
                n_match += 1
                print("\n{:>30}: \nReal: {:>26}   Classifier: {:>30}  \nPetLabelDog: {:1d}  ClassLabelDog: {:1d}".format(key,
                      results_dic[key][0], results_dic[key][1], results_dic[key][3], 
                      results_dic[key][4]))

        # Print all non-matches next
        print("\n NOT A MATCH:")
        for key in results_dic:
        
            # Print only if not a match (Index 2 == 0)
            if results_dic[key][2] == 0:
 
                # Increment non-match counter
                n_notmatch += 1
                print("\n{:>30}: \nReal: {:>26}   Classifier: {:>30}  \nPetLabelDog: {:1d}  ClassLabelDog: {:1d}".format(key,
                      results_dic[key][0], results_dic[key][1], results_dic[key][3], 
                      results_dic[key][4]))

        # Print total number of images, matches, and non-matches
        print("\n# Total Images",n_match + n_notmatch, "# Matches:",n_match ,
              "# NOT Matches:",n_notmatch)

def check_calculating_results(results_dic, results_stats_dic):
    """    
    For Lab: Classifying Images - 14. Calculating Results
    Displays statistics from the results_stats dictionary (created by the 
    calculates_results_stats() function), then prints the same statistics
    calculated from the results dictionary.
    Assumes results_stats_dic dictionary and statistics were defined as 
    outlined in '14. Calculating Results '
    Parameters:
      results_dic - Dictionary with key as image filename and value as a List 
             (index)
