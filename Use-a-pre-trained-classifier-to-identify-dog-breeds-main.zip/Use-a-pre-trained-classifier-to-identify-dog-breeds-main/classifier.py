import ast
from PIL import Image
import torchvision.transforms as transforms
import torchvision.models as models
import torch

# Load pretrained models
models_dict = {
    'resnet': models.resnet18(pretrained=True),
    'alexnet': models.alexnet(pretrained=True),
    'vgg': models.vgg16(pretrained=True)
}

# Load ImageNet labels
with open('imagenet1000_clsid_to_human.txt') as file:
    imagenet_classes = ast.literal_eval(file.read())

def classifier(img_path, model_name):
    """
    Classifies an image using the specified model and returns the predicted class label.

    Parameters:
    img_path (str): Path to the image file.
    model_name (str): Name of the model to use ('resnet', 'alexnet', 'vgg').

    Returns:
    str: The predicted class label.
    """
    # Load the image
    img = Image.open(img_path)

    # Define preprocessing transforms
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    # Preprocess the image
    img_tensor = preprocess(img).unsqueeze(0)

    # Select the model
    if model_name not in models_dict:
        raise ValueError(f"Model {model_name} is not recognized. Choose from 'resnet', 'alexnet', or 'vgg'.")

    model = models_dict[model_name]
    model.eval()

    # Perform inference
    with torch.no_grad():
        output = model(img_tensor)
    
    # Get the predicted class index
    pred_idx = output.argmax().item()
    
    # Return the predicted class label
    return imagenet_classes[pred_idx]
