#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/print_results_hints.py
#                                                                             
# PROGRAMMER: Nensi Batra
# DATE CREATED: 15-08-2024
# REVISED DATE: 
# PURPOSE: This file provides hints for creating the print_results function.
#          The function prints results statistics from a dictionary and
#          can also display cases of misclassified dogs and breeds using 
#          the provided dictionaries.
# 
# This function:
#   - Prints a summary of classification results.
#   - Optionally prints incorrectly classified dogs and breeds.
# 
# Function inputs:
#   - results_dic: Dictionary with image filenames as keys and lists as values
#     containing details about pet and classifier labels.
#   - results_stats_dic: Dictionary with statistics such as counts and percentages.
#   - model: The CNN model architecture used (resnet, alexnet, or vgg).
#   - print_incorrect_dogs: Boolean to indicate whether to print misclassified dogs.
#   - print_incorrect_breed: Boolean to indicate whether to print misclassified breeds.
# 
# This function does not return any values but prints the results directly.
# 
def print_results(results_dic, results_stats_dic, model, 
                  print_incorrect_dogs=False, print_incorrect_breed=False):
    """
    Prints a summary of results based on the classification and optionally
    prints misclassified dogs and breeds if indicated.
    
    Parameters:
      results_dic - Dictionary with image filenames as keys and lists of 
                    classification details as values.
      results_stats_dic - Dictionary with statistics (counts and percentages).
      model - CNN model architecture used (resnet, alexnet, or vgg).
      print_incorrect_dogs - Boolean to print misclassified dogs.
      print_incorrect_breed - Boolean to print misclassified breeds.
      
    Returns:
      None - Directly prints the results.
    """
    # Print summary statistics
    print("\n\n*** Results Summary for CNN Model Architecture", model.upper(), "***")
    print("{:20}: {:3d}".format('N Images', results_stats_dic['n_images']))
    print("{:20}: {:3d}".format('N Dog Images', results_stats_dic['n_dogs_img']))
    print("{:20}: {:3d}".format('N Not-Dog Images', results_stats_dic['n_notdogs_img']))

    # Print percentage statistics
    print(" ")
    for key in results_stats_dic:
        if key.startswith("pct"):
            print(f"{key}: {results_stats_dic[key]:.1f}")

    # Print misclassified dogs if requested
    if print_incorrect_dogs and (results_stats_dic['n_correct_dogs'] + results_stats_dic['n_correct_notdogs'] != results_stats_dic['n_images']):
        print("\nINCORRECT Dog/NOT Dog Assignments:")
        for key in results_dic:
            if results_dic[key][3] + results_dic[key][4] == 1:
                print(f"Pet label: {results_dic[key][0]}\nClassifier label: {results_dic[key][1]}")

    # Print misclassified breeds if requested
    if print_incorrect_breed and (results_stats_dic['n_correct_dogs'] != results_stats_dic['n_correct_breed']):
        print("\nINCORRECT Dog Breed Assignment:")
        for key in results_dic:
            if sum(results_dic[key][3:]) == 1 and results_dic[key][2] == 0:
                print(f"Real: {results_dic[key][0]:>26}   Classifier: {results_dic[key][1]:>30}")
        for key in results_dic:
            if sum(results_dic[key][3:]) == 2 and results_dic[key][2] == 0:
                print(f"Real: {results_dic[key][0]:>26}   Classifier: {results_dic[key][1]:>30}")
