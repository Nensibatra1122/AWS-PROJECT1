#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND/intropylab-classifying-images/test_classifier.py
#                                                                             
# PROGRAMMER: Nensi Batra
# DATE CREATED: 15-08-2024
# REVISED DATE:             
# PURPOSE: This script demonstrates how to use the `classifier()` function 
#          defined in `classifier.py`. This function employs a pretrained CNN 
#          model to classify images. Supported model architectures are 'resnet', 
#          'alexnet', and 'vgg'. The script includes an example of usage.
#
# Usage: python test_classifier.py    -- Execute this script from the command line

# Import the classifier function to classify images using a pretrained CNN
from classifier import classifier 

# Specify a test image located in the pet_images folder
test_image = "pet_images/Collie_03797.jpg"

# Set the CNN model architecture for classification
# Supported models: 'vgg', 'alexnet', 'resnet'
model = "vgg"

# Use the classifier function to classify the image
# The result will be a string label, which may contain mixed case or multiple words separated by commas
image_classification = classifier(test_image, model)

# Display the result of the classification
print("\nResults from test_classifier.py\nImage:", test_image, "using model:",
      model, "was classified as:", image_classification)
